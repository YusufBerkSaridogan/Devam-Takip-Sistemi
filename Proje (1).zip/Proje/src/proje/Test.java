package proje;

public class Test {

    public static void main(String[] args) {
        System.out.println(Personel.mevcut);
//PERSONEL, YÖNETİCİ VE ŞİRKET TANIMLAMA YERİ
//        Personel p1 = new Personel("Yusuf", "Sarıdoğan", 24);
//        Personel p2 = new Personel("Yaren", "Bakan", 24);
//        Personel p3 = new Personel("Esed", "Tepeler", 20);
//        Personel p4 = new Personel("Tuğçe", "Ateş", 27);
//        Personel p5 = new Personel("Cengizhan", "Uçan", 19);
//        Personel p6 = new Personel("Osman", "Durdu", 27);
//        Personel p7 = new Personel("Emir", "İnan", 18);
//        Personel p8 = new Personel("Doğan", "Sancaklı", 45);
//        Personel p9 = new Personel("Tuna", "Şenveli", 49);
//        Personel p10 = new Personel("Baran", "Başkaya", 31);
//        Yonetici y1 = new Yonetici("Eyüp", "Ülkü", 40);
//        Kurul k1 = new Kurul("Fatih Sultan Mehmet", 1001);
//        Yonetici y2 = new Yonetici("Polat", "Alemdar", 45);
//        Yonetici y3 = new Yonetici("Ahmet", "Sapanca", 37);
//        y1.personelEkle(p1);
//        y1.personelEkle(p2);
//        y1.personelEkle(p3);
//        y1.personelEkle(p4);
//        y1.personelEkle(p5);
//        y1.personelEkle(p6);
//        y1.personelEkle(p7);
//        y1.personelEkle(p8);
//        y1.personelEkle(p9);
//        y1.personelEkle(p10);
//        k1.yoneticiEkle(y1);
////        k1.yoneticiEkle(y2);
////        k1.yoneticiEkle(y3);
//
//// ŞİRKET, YÖNETİCİ VE PERSONEL BİLGİLERİNİ ÇAĞIRMA METOT YERİ
//        k1.sirketBilgileri();
//        y1.personelSayi();
//        k1.yoneticiListele();
//        y1.personelListele();
//        System.out.println("*********************************************");
//
////YÖNETİCİ VE PERSONEL GİRİŞ  METOT YERİ
//        y1.yoneticiGiris();
////        y2.yoneticiGiris();
//        p1.personelGiris();
//        p2.personelGiris();
////        p3.personelGiris();
//        p5.personelGiris();
//        p8.personelGiris();
//        System.out.println("**********************************");
//
////İŞE GELEN PERSONELLERİN SAYISININ VE GELİP GELMEDİĞİNİ KONTROL ETME METOT YERİ
//        y1.mevcutPersonelSayi();
//        System.out.print(p1.getAd() + "\t" + p1.getSoyad() + ": ");
//        y1.geldiMi(p1);
//        System.out.print(p2.getAd() + "\t" + p2.getSoyad() + ": ");
//        y1.geldiMi(p2);
//        System.out.println("************");
//
////PERSONELLERİN İZİN TALEP ETTİĞİ VE YÖNETİCİNİN TATİL VERDİĞİ METOT YERİ    
//        p1.izinTalep();
//        y1.personelTatil(p2);
//// PERSONELLERİN ÇALIŞTIĞI SAATLERİ GİRME METOT YERİ    
//        p1.saaT(8.8);
//        p2.saaT(10);
//        p3.saaT(12);
//        p6.saaT(6);
//        p5.saaT(9);
//        p8.saaT(6);
//        p10.saaT(7);
//
//// PERSONEL ÇIKIŞ YAPMA METOT YERİ    
//System.out.println();
//        p1.personelCikis();
//        p7.personelCikis();
//        p10.personelCikis();
//
//// PERSONEL VE YÖNETİCİ EKLEYİP SİLME METOT YERİ    
////            y1.personelSil(p1);                          
////            k1.yoneticiSil(y1);
////            k1.yoneticiSil(y2);
//// PERSONEL SAAT ÇİZELGE KONTROL METOT YERİ
//        y1.saatCizelge();
//
//// ÇIKARMA YA DA EKLEME İŞLEMİ YAPILDIYSA LİSTENİN TEKRARDAN KONTROL EDİLME METOT YERİ     
//           y1.personelListele();
//           k1.yoneticiListele();
    }

}
